#pragma once
#include "stdafx.h"

void MsgCenterSendToVirus(LPCWSTR buff, HWND form);
void MsgCenteAppendHWND(HWND hWnd);
void MsgCenterSendHWNDS(HWND fromHWnd);
