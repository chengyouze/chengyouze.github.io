﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 JiYuTrainer.rc 使用
//
#define IDD_DIALOG_ARGEEMENT            104
#define IDD_DIALOG_AVTIP             105
#define IDR_DLL_DRIVER                  130
#define IDR_DLL_HOOKS                   131
#define IDR_DLL_SCITER                  134
#define IDI_APP_MAIN                         135
#define IDI_WARN                        147
#define IDC_STATIC_RED                  32770
#define IDC_CHECK_DONOT_SHOW_AGAIN      1024
#define IDC_MESSAGE                     1025
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
