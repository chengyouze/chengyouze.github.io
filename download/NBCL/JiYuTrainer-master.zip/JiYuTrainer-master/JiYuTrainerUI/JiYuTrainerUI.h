#pragma once
#include "stdafx.h"

UIEXPORT_CFUNC(int) JiYuTrainerUICommonEntry(int i);

