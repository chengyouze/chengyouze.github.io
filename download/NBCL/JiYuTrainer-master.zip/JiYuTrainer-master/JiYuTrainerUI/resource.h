//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� JiYuTrainerUI.rc ʹ��
//
#define IDI_APP                         101
#define IDR_HTML_MAIN                   103
#define IDR_MAINMENU                    113
#define IDR_HTML_ABOUT                  119
#define IDR_HTML_UPDATER                121
#define IDD_SETTINGS                    127
#define IDD_BUGREPORT                   129
#define IDI_BUG                         131
#define IDI_CLOSE                       139
#define IDI_HELP                        140
#define IDB_CLOSE                       141
#define IDB_HELP                        142
#define IDI_WARN                        147
#define IDD_SETTINGS_MORE               148
#define IDD_SETTINGS_DEBUG              149
#define IDR_HTML1                       150
#define IDR_HTML_ATTACK                 150
#define IDR_HTML2                       152
#define IDR_HTML_SCANIP                 152
#define IDC_CHECK_INI_11                1001
#define IDC_CHECK_INI_12                1002
#define IDC_CHECK_INI_21                1003
#define IDC_CHECK_INI_14                1004
#define IDC_CHECK_INI_15                1005
#define IDC_CHECK_INI_24                1006
#define IDC_CHECK_INI_25                1007
#define IDC_CHECK_INI_22                1008
#define IDC_CHECK_INI_23                1009
#define IDC_COMBO_INJECT_MODE           1010
#define IDC_KILLPROC_TP                 1011
#define IDC_KILLPROC_NTP                1012
#define IDC_KILLPROC_PPTP_APC           1013
#define IDC_ABOUT                       1014
#define IDC_REBOOT                      1015
#define IDC_BUGREPORT_CONTENT           1017
#define IDC_CKINTERVAL                  1018
#define IDC_SAVE                        1019
#define IDC_CHECK_INI_13                1020
#define IDC_CHECK_INI_16                1021
#define IDC_CHECK_DONOT_SHOW_AGAIN      1024
#define IDC_MESSAGE                     1025
#define IDC_TAB_SETTINGS                1026
#define IDC_CHECK_INI_17                1027
#define IDC_HOTKEY_FK                   1028
#define IDC_HOTKEY_SHOWHIDE             1029
#define IDM_HELP                        32774
#define IDM_EXIT                        32775
#define IDM_SHOWMAIN                    32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
