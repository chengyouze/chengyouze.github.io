#pragma once
#include "stdafx.h"

void ShowBugReportWindow();

INT_PTR CALLBACK BugReportDlgFunc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
