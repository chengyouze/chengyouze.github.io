//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� JiYuTrainerHooks.rc ʹ��
//
#define IDD_MSGCT                       101
#define IDD_OPASK                       107
#define IDI_ICONWARN                    109
#define IDD_OUTCTL                      110
#define IDB_BITMAP_GREEN                112
#define IDB_BITMAP_GRRY                 113
#define IDB_BITMAP_RED                  114
#define IDD_FAKEDESKTOP                 115
#define IDI_ICONAPP                     118
#define IDI_ICONCLOSE                   119
#define IDI_ICONHELP                    120
#define IDB_HELP                        121
#define IDB_APP                         122
#define IDB_EXIT                        123
#define IDC_STATUS_TEXT                 1001
#define IDC_STATUS_LIST                 1002
#define IDC_KILL                        1003
#define IDC_SMINSIZE                    1004
#define IDC_EDIT_OP_PATH                1004
#define IDC_SHIDE                       1005
#define IDC_EDIT_OP_PARARM              1006
#define IDC_CHECK_BANDALL               1007
#define IDC_RESTART                     1008
#define IDC_CHECK_ALOW                  1009
#define IDC_STATUS_RUNNING              1010
#define IDC_STATUS_LOCK                 1011
#define IDC_STATUS_FAKEFULL             1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
